package com.hotel.vo;

public class MyroomVO {
	String mid,bid,radatestart,radateend,price,brname,booknum;


	public String getBooknum() {
		return booknum;
	}

	public void setBooknum(String booknum) {
		this.booknum = booknum;
	}
	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getBid() {
		return bid;
	}

	public void setBid(String bid) {
		this.bid = bid;
	}

	public String getRadatestart() {
		return radatestart;
	}

	public void setRadatestart(String radatestart) {
		this.radatestart = radatestart;
	}

	public String getRadateend() {
		return radateend;
	}

	public void setRadateend(String radateend) {
		this.radateend = radateend;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getBrname() {
		return brname;
	}

	public void setBrname(String brname) {
		this.brname = brname;
	}
	
	
}
