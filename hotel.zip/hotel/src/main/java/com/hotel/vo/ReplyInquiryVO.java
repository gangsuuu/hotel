package com.hotel.vo;

public class ReplyInquiryVO {

	//����
	String reid, recontent, redate, iid;
	int rno, hcount;
	
	
	//getter,setter
	public int getHcount() {
		return hcount;
	}
	
	public void setHcount(int hcount) {
		this.hcount = hcount;
	}
	
	public String getReid() {
		return reid;
	}
	public void setReid(String reid) {
		this.reid = reid;
	}
	public String getRecontent() {
		return recontent;
	}
	public void setRecontent(String recontent) {
		this.recontent = recontent;
	}
	public String getRedate() {
		return redate;
	}
	public void setRedate(String redate) {
		this.redate = redate;
	}
	public String getIid() {
		return iid;
	}
	public void setIid(String iid) {
		this.iid = iid;
	}
	public int getRno() {
		return rno;
	}
	public void setRno(int rno) {
		this.rno = rno;
	}
	
	
}
