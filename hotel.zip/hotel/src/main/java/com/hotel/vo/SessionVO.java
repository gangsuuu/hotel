package com.hotel.vo;

public class SessionVO {

	//��������
	int loginresult;
	String mid;
	
	//setter,getter
	public int getLoginresult() {
		return loginresult;
	}
	public void setLoginresult(int loginresult) {
		this.loginresult = loginresult;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	
	
	
}
