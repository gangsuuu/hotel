package com.hotel.vo;

public class BookVO {
	String mid,bid,radatestart,radateend,price,booknum;


	public String getBooknum() {
		return booknum;
	}

	public void setBooknum(String booknum) {
		this.booknum = booknum;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getMid() {
		return mid;
	}
	
	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getBid() {
		return bid;
	}

	public void setBid(String bid) {
		this.bid = bid;
	}

	public String getRadatestart() {
		return radatestart;
	}

	public void setRadatestart(String radatestart) {
		this.radatestart = radatestart;
	}

	public String getRadateend() {
		return radateend;
	}

	public void setRadateend(String radateend) {
		this.radateend = radateend;
	}

}
